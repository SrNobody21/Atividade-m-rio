[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Bzu4gyEW)
# CRUD de Alunos em PHP

Este projeto é um exemplo de implementação simples de um sistema CRUD para a entidade **Aluno** usando PHP e banco de dados.

## Modelo Entidade-Relacionamento (MER)

```mermaid
erDiagram
    ALUNO {
        int id PK
        string uuid
        string matricula
        string nome
        string email
        date data_nascimento
    }
```

## Checklist para Implementação

### 1. Preparar o ambiente

- [ ] Configurar o PHP no seu ambiente (se for nos laboratórios, já deve estar configurado.)
- [ ] Configurar o banco de dados SQLite.
- [ ] Criar um banco de dados (ex: `atividade_db.sqlite`).

### 2. Configuração do banco de dados

- [ ] Criar a tabela `Aluno` com os seguintes campos:
  - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
  - `uuid` (VARCHAR(36), UNIQUE)
  - `matricula` (VARCHAR(20), UNIQUE)
  - `nome` (VARCHAR(100))
  - `email` (VARCHAR(100), UNIQUE)
  - `data_nascimento` (DATE)
- [ ] Testar a conexão com o banco de dados usando PHP.

### 3. Criar a estrutura do projeto

- [ ] Criar o arquivo de configuração para conexão com o banco (`db_connect.php`).

### 4. Operações CRUD

#### a) Create (Inserir um novo aluno)

- [ ] Criar o formulário em HTML para inserir dados de aluno.
- [ ] Implementar a lógica para inserir dados no banco (arquivo PHP para "Create").

#### b) Read (Listar alunos)

- [ ] Criar uma página para listar todos os alunos.
- [ ] Implementar a lógica para buscar e exibir os alunos cadastrados.

#### c) Update (Atualizar informações de um aluno)

- [ ] Criar um formulário para editar dados de um aluno existente.
- [ ] Implementar a lógica para atualizar os dados no banco.

#### d) Delete (Deletar aluno)

- [ ] Implementar a função para deletar um aluno usando o `id` como referência.
- [ ] Criar botões ou links para exclusão na página de listagem.

### 5. Testar as funcionalidades

- [ ] Testar cada operação CRUD para verificar o funcionamento adequado.
- [ ] Validar campos obrigatórios (nome, matrícula, email, data de nascimento) no lado cliente e servidor.
- [ ] Testar a validação dos campos.
- [ ] Incluir proteção contra SQL Injection usando `prepared statements`.

### 6. Melhorias opcionais

- [ ] Garantir que o email seja único e tenha o formato correto.
- [ ] Garantir que a matrícula e o UUID sejam únicos.

#### Bônus

- [ ] Adicionar paginação à listagem de alunos.
- [ ] Implementar busca por nome ou matrícula na listagem.
